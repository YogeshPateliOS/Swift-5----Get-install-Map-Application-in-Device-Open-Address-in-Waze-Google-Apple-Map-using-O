//
//  ViewController.swift
//  MapYoutube
//
//  Created by Yogesh Patel on 14/08/19.
//  Copyright © 2019 Yogesh Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet var txtAddress: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnMapClick(_ sender: UIButton) {
        self.present(MapAppFinder.shareInstance.directionsAlertController(address: txtAddress.text!, completion: nil), animated: true, completion: nil)
    }
}

